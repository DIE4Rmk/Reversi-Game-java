public interface ConsoleMenu {
    String ANSI_RESET = "\u001B[0m";
    String ANSI_BLUE = "\u001B[34m";
    String ANSI_RED = "\u001B[31m";
    String ANSI_GREEN = "\u001B[32m";
    String ANSI_BLACK = "\u001B[30m";
    String ANSI_WHITE_BACKGROUND = "\u001B[47m";
    String ANSI_BLACK_BACKGROUND = "\u001B[40m";

}
